import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css'],
})
export class UserListComponent implements OnInit {
  newUser: any = {
    company: {
      name: '',
    },
  };
  users: any[] = [];
  display: string = 'none';
  recordCreated = false;

  constructor(private userService: UserService ) {}

  ngOnInit() {

    this.userService.getUsers().subscribe((data: any) => {
      this.users = data;

      const storedUsers = sessionStorage.getItem('users');
      if (storedUsers) {
        const sessionUsers = JSON.parse(storedUsers);
        this.users = [...this.users, ...sessionUsers];
      }
    });
  }

  toggleModal() {
    this.display = 'block';
  }

  toggleCancel() {
    this.display = 'none';
  }

  onSubmit() {
    // Save the new user to session storage
    const storedUsers = sessionStorage.getItem('users');
    const users = storedUsers ? JSON.parse(storedUsers) : [];
    users.push(this.newUser);
    sessionStorage.setItem('users', JSON.stringify(users));

    // Add the new user to the local array
    this.users.push(this.newUser);

    // Reset the newUser object
    this.newUser = {
      company: {
        name: '',
      },
    };
    // Close the modal
    this.display = 'none';
    // Set timeout for creation of user
    this.recordCreated = true;
    setTimeout(() => {
      this.recordCreated = false;
    }, 2000);
  }
}
